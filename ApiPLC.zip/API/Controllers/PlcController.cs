﻿using API.Models;
using API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    /// <summary>
    /// OBS.: Todas as requisições tentam executar automaticamente uma conexão com o servidor!
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class PlcController : ControllerBase
    {
        private readonly PlcService _plcService;

        public PlcController(PlcService plcService)
        {
            _plcService = plcService;
        }

        /// <summary>
        /// Inicia uma conexão com o PLC
        /// </summary>
        /// <returns></returns>
        [HttpGet("connect")]
        public async Task<IActionResult> Connect()
        {
            await _plcService.ConnectAsync();
            return Ok("Connected to PLC");
        }

        /// <summary>
        /// Encerra a conexão com o PLC
        /// </summary>
        /// <returns></returns>
        [HttpGet("disconnect")]
        public IActionResult Disconnect()
        {
            _plcService.Disconnect();
            return Ok("Disconnected from PLC");
        }

        /// <summary>
        /// Executa a leitura de um valor no PLC
        /// </summary>
        /// <param name="addressplc"></param>
        /// <returns></returns>
        [HttpGet("read/{addressplc}")]
        public async Task<IActionResult> Read(string addressplc)
        {
            var result = await _plcService.ReadAsync<object>(addressplc);
            return Ok(result);
        }

        /// <summary>
        /// Executa a escrita de um novo valor no PLC
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("write")]
        public async Task<IActionResult> Write( WriteRequest request)
        {
            await _plcService.WriteAsync(request.AddressPlc, request.Value);
            return Ok("Write successful");
        }

        /// <summary>
        /// Alterna entre os valores 0 e 1
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("startstop")]
        public async Task<IActionResult> StartStop( StartStopRequest request)
        {
            await _plcService.StartStop(request.AddressPlc);
            return Ok("Toggled value successfully");
        }
    }

}
