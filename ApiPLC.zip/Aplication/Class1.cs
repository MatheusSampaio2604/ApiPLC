﻿namespace Aplication
{
    public class Class1
    {

    }
}
